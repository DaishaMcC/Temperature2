function getTEMP(){
    var celsius= Number(prompt("Enter Celsius number here"));

    var fahrenheit=(celsius*9/5)+ 32;

    document.write("Fahrenheit: " + fahrenheit);
}